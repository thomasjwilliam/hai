/**
 * content script that listens to GetDocumentBody messages coming from the context module
 * returns the html of the page
 */
(async () => {
  chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.type === "GetDocumentBody") {
      sendResponse({
        ok: true,
        data: document.all[0].outerHTML
      });
    }
  });
})();
