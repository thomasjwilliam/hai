/**
 * https://stackoverflow.com/a/66408379
 */
const importedScripts = []

function tryImport(...fileNames) {
  try {
    const toRun = new Set(fileNames.filter((f) => !importedScripts.includes(f)))
    if (toRun.size) {
      importedScripts.push(...toRun)
      importScripts(...toRun)
    }
    return true
  } catch (e) {
    console.error(e)
  }
}

self.oninstall = () => {
  tryImport("/service/service.js")
}

/**
 * TODO: find a stable permanent solution
 * Currently using the "Persistent service worker via bug exploit" from
 * https://stackoverflow.com/a/66618269
 */
const keepAlive = () => setInterval(chrome.runtime.getPlatformInfo, 20e3)
chrome.runtime.onStartup.addListener(keepAlive)
keepAlive()
