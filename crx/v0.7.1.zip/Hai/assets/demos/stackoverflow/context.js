/**
 * Source of the script included in context.json
 * Minify the script function with https://minify-js.com/
 * Copy the minified result, without the script function wrapper, in context.json "script" property, but make sure to escape quotes
 */
function script() {
  const title = document.querySelector("#question-header h1").textContent.trim()

  const question = document.getElementsByClassName("question")[0]
  const author = question
    .querySelector(".post-signature > .user-info > .user-details > span")
    .textContent.trim()
  const asked = document.querySelectorAll('time[itemprop="dateCreated"]')[0]
    .textContent
  const timesViewed = Array.from(document.querySelectorAll("*"))
    .filter((el) => el.textContent === "Viewed")[0]
    .parentElement.textContent.replace("Viewed", "")
    .trim()
  return {title, author, asked, timesViewed}
}
