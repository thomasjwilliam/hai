/**
 * Source of the gmail context script, to be used in gmail-context.json
 * Minify the script function with https://minify-js.com/
 * Copy the minified result, without the script function wrapper, in gmail-context.json "script" property
 * Attention: make sure to escape quotes
 */
function script() {
  const subject = document.querySelector('h2[jsname="r4nke"]').textContent

  const senderNames = document.querySelectorAll("h3.iw .gD")
  const senderNameFirst = senderNames[0].textContent
  const senderNameLast =
    senderNames.length === 1
      ? senderNames[0].textContent
      : senderNames[senderNames.length - 1].textContent

  const senderAddresses = document.querySelectorAll("h3.iw .go")
  const senderAddressFirst = senderAddresses[0].textContent.slice(1, -1)
  const senderAddressLast =
    senderAddresses.length === 1
      ? senderAddressFirst
      : senderAddresses[senderAddresses.length - 1].textContent.slice(1, -1)

  const datetimes = document.querySelectorAll(".gK .g3")
  const datetimeFirst = datetimes[0].textContent
  const datetimeLast =
    datetimes.length === 1
      ? datetimes[0].textContent
      : datetimes[datetimes.length - 1].textContent

  return {
    from: {
      address: senderAddressFirst,
      name: senderNameFirst,
    },
    lastMessage: {
      address: senderAddressLast,
      name: senderNameLast,
      received: datetimeLast,
    },
    received: datetimeFirst,
    subject: subject,
  }
}
