/**
 * Source of the script included in context.json
 * Minify the script function with https://minify-js.com/
 * Copy the minified result, without the script function wrapper, in context.json "script" property, but make sure to escape quotes
 */
function script() {
  const element = document.getElementById("firstHeading");
  const text = element.innerText || element.textContent;
  return {
    title: text
  };
}
