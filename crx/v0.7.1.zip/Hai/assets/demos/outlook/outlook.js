/**
 * Source of the Outlook context script, to be used in outlook.json
 * Minify the script function with https://minify-js.com/
 * Copy the minified result, without the script function wrapper, in gmail.context.json "script" property
 * Attention: make sure to escape quotes
 */
function script() {
  const date = document.querySelector(".srQCs").textContent

  const fromAddressAndName = document.querySelector(".OZZZK").textContent
  const address = fromAddressAndName
    .substring(
      fromAddressAndName.indexOf("<") + 1,
      fromAddressAndName.indexOf(">")
    )
    .trim()
  const name = fromAddressAndName
    .substring(0, fromAddressAndName.indexOf("<"))
    .trim()

  const subject = document.querySelector(".JdFsz").getAttribute("title")

  return {
    date,
    from: {
      address,
      name,
    },
    subject,
  }
}
