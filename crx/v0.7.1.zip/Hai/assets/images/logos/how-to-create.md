# How to generate logo
generate an svg image

## Convert to png
### On Mac
```
cd into this folder
/usr/bin/sips -s format png -o <file-name>.png <file-name>.svg
```
